matrix = [[0,0,0]*3]
print(matrix)




mat1 = list('....')
print(mat1)